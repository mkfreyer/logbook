# Reprise M4A alternatives — 18 octobre 2026

Objectif utilisateur : comparer 2–3 meilleures nouvelles bases réellement rendues
entièrement, face/3quarts/dos, même matériau et lumière. MakeHuman/MPFB obligatoire
dans l’étude, corps athlétique, licence app commerciale propriétaire, segmentation
musculaire possible et optimisation iPhone. Stop pour choix utilisateur après
comparaison ; pas moteur/M4B/SQLite/fusion/reconstruction BodyParts3D. Aucun agent
ou changement de modèle ; user veut Sol6.1 Élevé et décision avant Astra Ultra.

Branche feat/m4a-prototype-carte-musculaire-3d ; PR11 brouillon ; dernier commit
7fb0962bfead3d37363d1a20d8af81caa5a8de89 publié. Docs M4A_CHOIX_MODELE.md indique
explicitement comparaison incomplète. MPFB généré/rendu et géométrie reproduite
identiquement. Pas de code applicatif modifié.

Sources scratch :
- sources/mpfb2, commit3af0cd5a2ffba072e93a34e5f6f494fdc4813ddf,108Mo, addon2.0.18,
  coreassetsCC0,codeGPL. Basemesh+targets tous présents.
- sources/makehuman-eyes : low-poly.obj/mhclo et LICENSE.md du commitMakeHuman
  a8bc2d54ff0ac92e78ff71431b1023eda42bf482,CC0. Matériaux ignorés pour shadercommun.
- mpfb-athletic-probe.blend : sourcegénérée2obj MPFB_Athletic_Body, MPFB_Core_Eyes.
- mpfb-settings.json : macros homme1/adulte0.5/muscle1/poids0.35/proportions0.55,
  stomach-tone0.6, pectoral/dorsi0.25 ; touscoretargetsAPIofficielle.
- renders/mpfb-athletic :3PNG900x1400CyclesCPU128samples,protocol sourcebranchtools.
- generation-reproduction-check.json : body13380v/13378quads/26756tri,
  hash1710848caec30b917beb3d539c150291d24434fd483e92d058265f1a0b96a7d0 ; yeux96v/86faces,
  hash18029462efd56ecf32712e0e2c5ef7e0a7aad7b268df783548b387033ec3c957.

Blocage ACTUEL : runtime réseau ancien : sourceversioncecfgver_6ad31df6892481a2ae9f72e6c5584c00,
revision23, allowedhosts api.expo.dev/api.github.com/dbarchive.biosciencedbc.jp/docs.expo.dev.
download.blender.org absent, HTTP CONNECT403 prouvé. User a dit configuration
publiée, mais runtime et fichierpolicy inchangés. Demande async redémarrage envoyée ;
user répond « Je vérifie la configuration ». Attendre nouvelleconfigurationactive.
Ne pas contournerproxy/changerroute/utiliserautremiroirpourbypass.

Source Blender prévue :
https://download.blender.org/demo/asset-bundles/human-base-meshes/human-base-meshes-bundle-v1.4.1.zip
Indexofficiel/websearch annonce50643039octets,CC0surpageofficiellede demo-files.
Pas récupérée ni licenceinternelue. ChercherrealisticmalebyDanUlrichetstylizedmale
byJulienKaspar dans bundle, inspecterqualité avantretenir2ou3candidats.

Après déblocage : téléchargerarchiveofficielle,tailleSHA/CRC,extractionsafe.
Listercollections/objets/asset_data auteur/licence/niveauxsubdivision/multires.
ATTENTION render_comparison.py évalue actuellementmodificateursviewport avant
aplatissement,puisajoute1subdivisioncommune. Pour source sculptéeMultires, vérifier
que niveauxaffichésconserventsculpture,pascomparerinjustementunebasebruteprivée
desdétails. Enregistrerchoixrésolution/modificateurs ; éviter4mfaces×4inutilement.
Mêmesmatériaux/lights/cameraheightnormalisée ; posesnativessignalées,corpsentier.
MPFB natifApose largeur1.18145 pourhauteur1.8,camortho2.30ratio900/1400cadrageOK.
Si autreTposepluslarge,cadrerles2avecmêmenouvelleéchelleetrecalculerMPFB3vues.

ConstatsMPFB : corpscontinusourcepropre mais définitionmusclesfaible face/dos,
nonvalidévisuellement. Segmentationàpeindresurfacegauche/droite,groupesrig/helpers
ne sont pasmuscles. OptimisationgéométriquefaiblecomplexitéaucunFPSpromis.

Autrespistesdéjà étudiées :
- AlexLashkoMuscularMaleBasemeshCGTrader49USD,lowest18002polys,vendorOBJ/ZTL,
  RFnoAI+incorporationanti-extraction. Pasacheté/pasrendu.
- SakoStylizedMuscularMaleAnatomyBasemeshesCGTrader15USD,low34000poly,
  BLEND/FBX/OBJ rig,RF. Pasacheté/pasrendu.
- 3DScanStore EXCLU : terms-and-conditions-licensing interdit online/offline
  anatomy/photography viewer mêmecommercialstandard. Ne pasproposercommecompatible.
- FabPolyOnefreebasemesh8.7ktris peu défini,licenceselectednonexposé,
  pas récupéré,n'étaitpasmeilleurcandidat.

Tous les résultats actuellement publiés restent des preuves partielles.
Ne pas demander choixfinalavant2–3vraiesbasesrendues. Relire docs rapport avant
miseàjour, ne pas répéterauditBodyParts/MPFB déjàfait.
