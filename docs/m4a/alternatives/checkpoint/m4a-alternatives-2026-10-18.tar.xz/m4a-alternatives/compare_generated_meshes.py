import bpy,json,hashlib,struct
from pathlib import Path
root=Path('/workspace/work/m4a-alternatives')
results=[]
for path in [root/'mpfb-athletic-probe.blend',root/'reproduction/mpfb-athletic.blend']:
    bpy.ops.wm.open_mainfile(filepath=str(path))
    graph=bpy.context.evaluated_depsgraph_get()
    objects=[]
    for name in ['MPFB_Athletic_Body','MPFB_Core_Eyes']:
        ob=bpy.data.objects[name];mesh=bpy.data.meshes.new_from_object(ob.evaluated_get(graph),depsgraph=graph)
        digest=hashlib.sha256()
        for v in mesh.vertices:digest.update(struct.pack('<3f',*(ob.matrix_world@v.co)))
        for face in mesh.polygons:
            digest.update(struct.pack('<I',len(face.vertices)))
            for i in face.vertices:digest.update(struct.pack('<I',i))
        objects.append({'object':name,'vertices':len(mesh.vertices),'polygons':len(mesh.polygons),'geometry_sha256':digest.hexdigest()})
    results.append({'file':path.name,'objects':objects})
assert results[0]['objects']==results[1]['objects'],results
(root/'generation-reproduction-check.json').write_text(json.dumps({'result':'identical evaluated geometry','runs':results},indent=2)+'\n')
print('REPRODUCTION_OK',json.dumps(results[0]['objects']))
