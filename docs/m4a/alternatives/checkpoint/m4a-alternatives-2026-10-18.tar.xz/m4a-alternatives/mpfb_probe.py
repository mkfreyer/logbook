import sys, bpy, json, types, importlib.util, importlib
from pathlib import Path
root=Path('/workspace/work/m4a-alternatives')
bpy.context.preferences.system.use_online_access=False
package='bl_ext.logbook_audit.mpfb'
for name in ['bl_ext','bl_ext.logbook_audit']:
    if name not in sys.modules:
        module=types.ModuleType(name);module.__path__=[];sys.modules[name]=module
spec=importlib.util.spec_from_file_location(package,root/'sources/mpfb2/src/mpfb/__init__.py',submodule_search_locations=[str(root/'sources/mpfb2/src/mpfb')])
module=importlib.util.module_from_spec(spec);sys.modules[package]=module;spec.loader.exec_module(module)
prefs=importlib.import_module(package+'._preferences').MpfbPreferences
bpy.utils.register_class(prefs)
entry=bpy.context.preferences.addons.new();entry.module=package
entry.preferences.mpfb_user_data=str(root/'blender-user/mpfb')
(root/'blender-user/mpfb').mkdir(parents=True,exist_ok=True)
module.register()
HumanService=importlib.import_module(package+'.services.humanservice').HumanService
TargetService=importlib.import_module(package+'.services.targetservice').TargetService
ExportService=importlib.import_module(package+'.services.exportservice').ExportService
info=TargetService.get_default_macro_info_dict()
info.update(gender=1.0,age=0.5,muscle=1.0,weight=0.35,proportions=0.55)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
obj=HumanService.create_human(macro_detail_dict=info)
obj.name='MPFB_Athletic_Body'
for fragment,weight in [('stomach/stomach-tone-incr',0.6),('torso/torso-muscle-pectoral-incr',0.25),('torso/torso-muscle-dorsi-incr',0.25)]:
    TargetService.load_target(obj,str(root/'sources/mpfb2/src/mpfb/data/targets'/(fragment+'.target.gz')),weight=weight)
eyes=HumanService.add_mhclo_asset(str(root/'sources/makehuman-eyes/low-poly.mhclo'),obj,asset_type='Eyes',subdiv_levels=1,material_type='NONE',set_up_rigging=False,import_weights=False)
eyes.name='MPFB_Core_Eyes'
ExportService.bake_modifiers_remove_helpers(obj,bake_masks=True,bake_subdiv=False,remove_helpers=True,also_proxy=False)
print('GENERATED',len(obj.data.vertices),len(obj.data.polygons),[m.name for m in obj.modifiers])
bpy.ops.wm.save_as_mainfile(filepath=str(root/'mpfb-athletic-probe.blend'))
(root/'mpfb-settings.json').write_text(json.dumps({'macros':info,'detail_targets':{'stomach/stomach-tone-incr':0.6,'torso/torso-muscle-pectoral-incr':0.25,'torso/torso-muscle-dorsi-incr':0.25},'objects':[obj.name,eyes.name]},indent=2)+'\n')
