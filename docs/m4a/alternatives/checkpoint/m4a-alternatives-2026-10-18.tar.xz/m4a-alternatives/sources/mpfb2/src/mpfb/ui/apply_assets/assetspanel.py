"""This is the root panel for the asset library."""

from ... import ClassManager
from ...services import LogService
from ...services import UiService
from ...services import AssetService
from ..abstractpanel import Abstract_Panel
from ..systemassets import get_system_assets_status, get_system_assets_lines, STATUS_OK
from ...services import SceneConfigSet

_LOG = LogService.get_logger("ui.assetspanel")

FILTER_PROPERTIES = SceneConfigSet([
    {
    "type": "string",
    "name": "filter",
    "description": "Only list assets with this term in the title",
    "label": "Title must contain",
    "default": ""
    },
    {
    "type": "string",
    "name": "packname",
    "description": "Only list assets belonging to an asset pack matching this name",
    "label": "Pack name must contain",
    "default": ""
    },
    {
    "type": "boolean",
    "name": "only_equipped",
    "description": "Only show assets which are currently equipped",
    "label": "Only equipped",
    "default": False
    }
    ], 'APAS_')

class MPFB_PT_Assets_Panel(Abstract_Panel):
    bl_label = "Apply assets"
    bl_category = UiService.get_value("MATERIALSCATEGORY")
    bl_order = 40

    def system_assets(self, layout):
        status = get_system_assets_status()
        if status == STATUS_OK:
            return
        box = layout.box()
        box.label(text="NOTE ABOUT SYSTEM ASSETS")
        box.label(text="")
        for line in get_system_assets_lines(status):
            box.label(text=line)

    def draw(self, context):
        _LOG.enter()
        layout = self.layout

        self.system_assets(layout)

        box = layout.box()
        box.label(text="Filter")
        show_props = ["filter"]
        if AssetService.get_pack_names():
            _LOG.debug("There is pack metadata")
            show_props.append("packname")
        else:
            _LOG.debug("There is no pack metadata")
        show_props.append("only_equipped")
        FILTER_PROPERTIES.draw_properties(context.scene, box, show_props)

ClassManager.add_class(MPFB_PT_Assets_Panel)
