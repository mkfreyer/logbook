import bpy, json

_ORIGINAL_NODE_DEF = json.loads("""
{
    "attributes": {
        "color": {
            "class": "Color",
            "name": "color",
            "value": [
                0.608,
                0.608,
                0.608
            ]
        },
        "height": {
            "class": "float",
            "name": "height",
            "value": 100.0
        },
        "location": {
            "class": "Vector",
            "name": "location",
            "value": [
                0.0,
                0.0
            ]
        },
        "use_custom_color": {
            "class": "bool",
            "name": "use_custom_color",
            "value": false
        },
        "width": {
            "class": "float",
            "name": "width",
            "value": 140.0
        }
    },
    "class": "ShaderNodeAddShader",
    "inputs": {
        "Shader": {
            "class": "NodeSocketShader",
            "default_value": null,
            "identifier": "Shader",
            "name": "Shader",
            "value_type": "SHADER"
        },
        "Shader_001": {
            "class": "NodeSocketShader",
            "default_value": null,
            "identifier": "Shader_001",
            "name": "Shader",
            "value_type": "SHADER"
        }
    },
    "outputs": {
        "Shader": {
            "class": "NodeSocketShader",
            "default_value": null,
            "identifier": "Shader",
            "name": "Shader",
            "value_type": "SHADER"
        }
    }
}""")

from .abstractnodewrapper import AbstractNodeWrapper

class _NodeWrapperShaderNodeAddShader(AbstractNodeWrapper):
    def __init__(self):
        AbstractNodeWrapper.__init__(self, _ORIGINAL_NODE_DEF)

snAddShader = _NodeWrapperShaderNodeAddShader()
